﻿/*
SAÜ-PDP Ödev-1
Berkay Özder B201200049
*/
namespace PDP_Blockchain
{
    public class Transaction
    {
        public string FromAddress { get; set; }
        public string ToAdress { get; set; }
        public int Amount { get; set; }
        public Transaction(string fromAdress, string toAddress, int amount)
        {
            FromAddress = fromAdress;
            ToAdress = toAddress;
            Amount = amount;
        }
    }
}
