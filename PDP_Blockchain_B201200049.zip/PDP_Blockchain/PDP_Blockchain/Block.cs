﻿/*
SAÜ-PDP Ödev-1
Berkay Özder B201200049
*/
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Text;

namespace PDP_Blockchain
{
    public class Block
    {
        public IList<Transaction> Transactions { get; set; }
        public int id { get; set; }
        public int Nonce { get; set; } = 0;
        public DateTime TimeStamp { get; set; }
        public string Hash { get; set; }
        public string   PreviousHash { get; set; }

        public Block(DateTime timeStamp, string previousHash, IList<Transaction> transactions)
        {
            id = 0;
            TimeStamp = timeStamp;
            PreviousHash = previousHash;
            Transactions = transactions;
        }
        public string CalculateHash()
        {
            SHA256 sha256= SHA256.Create();
            byte[] inbytes = Encoding.ASCII.GetBytes($"{Nonce}-{TimeStamp}-{PreviousHash ?? ""}-{JsonConvert.SerializeObject(Transactions)}");
            byte[] outbytes = sha256.ComputeHash(inbytes);
            return Convert.ToBase64String(outbytes);
        }
        public void Mine(int difficulty)
        {
            var leadingZeros = new string('0', difficulty);
            while (this.Hash==null || this.Hash.Substring(0, difficulty)!= leadingZeros)
            {
                this.Nonce++;
                this.Hash = this.CalculateHash();
            }
        }
    }
}
