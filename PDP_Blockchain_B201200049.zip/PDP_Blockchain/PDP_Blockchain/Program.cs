﻿/*
SAÜ-PDP Ödev-1
Berkay Özder B201200049
*/
using Newtonsoft.Json;
using System;

namespace PDP_Blockchain
{
    public class Program
    {
        static void Main(string[] args)
        {
            Blockchain ourblockchain = new Blockchain();
            DateTime startTime = DateTime.Now;

            ourblockchain.CreateTransaction(new Transaction("x1", "x2", 15));
            ourblockchain.ProcessPendingTransactions("x3");
            ourblockchain.CreateTransaction(new Transaction("x2", "x1", 10));
            ourblockchain.CreateTransaction(new Transaction("x2", "x1", 2));
            ourblockchain.ProcessPendingTransactions("x3");

            DateTime finishTime = DateTime.Now;

            Console.WriteLine(JsonConvert.SerializeObject(ourblockchain, Formatting.Indented));
            Console.WriteLine("Dogru mu? "+ourblockchain.IsValid().ToString());
            Console.WriteLine("Zaman:" + (finishTime - startTime).ToString());
            Console.ReadKey();


        }
    }
}
